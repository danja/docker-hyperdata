# this will download & install Fuseki
# init working graph
# load test graph
# set as default URLs/URIs
