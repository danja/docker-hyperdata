## Utils

* `server.js` - simple HTTP server (for convenience)
